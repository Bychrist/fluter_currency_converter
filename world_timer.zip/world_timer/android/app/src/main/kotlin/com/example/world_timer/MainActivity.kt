package com.example.world_timer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
