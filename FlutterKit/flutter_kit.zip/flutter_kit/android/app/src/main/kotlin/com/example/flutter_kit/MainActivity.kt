package com.example.flutter_kit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
